#ifndef ARDUINO_FATAL_H_
#define ARDUINO_FATAL_H_

#ifdef __cplusplus
extern "C" {
#endif

void fatal(const char *format, ...);

#ifdef __cplusplus
}
#endif

#endif /* #define ARDUINO_FATAL_H_ */